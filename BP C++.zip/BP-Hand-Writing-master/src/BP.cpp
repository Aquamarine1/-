#include<bits/stdc++.h>
using namespace std;
double f( double x)
{
	return 1.0/(1.0+exp(-x));
}
const int first=784;
const int second=100;
const int third=10;
const double alpha=0.35;
double W[first][second];
double WW[second][third];// Ȩ�� 
double B[second];
double BB[third];// ƫ��
double target[third];//ͼƬ��ע 
double H[first];//����� 
double HH[second];//���ز� 
double HHH[third];//����� 
double dt3[third];//���ݶ� 
double dt2[second];// 
double test_num = 0.0;
double test_success_count = 0.0;
void Forwardpropagation_1()
{
	for(int i=0;i<second;i++)
	{
	    double sum=0;
	    for(int j=0;j<first;j++)
	    {
	    	sum+=H[j]*W[j][i];
		}
		sum+=B[i];
		HH[i]=f(sum);
	}
}
void Forwardpropagation_2()
{
	for(int i=0;i<third;i++)
	{
	    double sum=0;
	    for(int j=0;j<second;j++)
	    {
	    	sum+=HH[j]*WW[j][i];
		}
		sum+=BB[i];
		HHH[i]=f(sum);
	}
}
void Perseus_3()
{
	for (int i = 0; i < third; i++){
		dt3[i] = (HHH[i]) * (1.0-HHH[i])/*ƫy��ƫw*/*(HHH[i]-target[i]);//ƫE��ƫy 
	}
}
void Perseus_2()
{
    for(int j=0;j<second;j++)
{
	double sum=0;
	for (int i = 0; i < third; i++){
		sum += WW[j][i] * dt3[i];
	}
	dt2[j] = (HH[j]) * (1.0-HH[j])/*ƫy��ƫw*/*sum;//ƫE��ƫy 
}
}
void feedback_3()
{
	for (int k = 0; k < third; k++){
		BB[k] = BB[k] - alpha * dt3[k];
		for (int j = 0; j < second; j++){
			WW[j][k] = WW[j][k] - alpha * HH[j] * dt3[k];
		}
	}
}
void feedback_2()
{
	for (int k = 0; k < second; k++){
		B[k] = B[k] - alpha * dt2[k];
		for (int j = 0; j < first; j++){
			W[j][k] = W[j][k] - alpha * H[j] /*ƫS��ƫW*/* dt2[k];
		}
	}
}
void initialize(){
	srand((int)time(0) + rand());
	for (int i = 0; i < first; i++){
		for (int j = 0; j < second; j++){
			W[i][j] = rand()%1000 * 0.001 - 0.5;
		}
	}	
	for (int j = 0; j < second; j++){
		for (int k = 0; k < third; k++){
			WW[j][k] = rand()%1000 * 0.001 - 0.5;
		}
	}

	for (int j = 0; j < second; j++){
		B[j] = rand()%1000 * 0.001 - 0.5;
	}
	for (int k = 0; k < third; k++){
		BB[k] = rand()%1000 * 0.001 - 0.5;
	}
}
void training(){
FILE *image_train;
	FILE *image_label;
	image_train = fopen("../tc/train-images.idx3-ubyte", "rb");
	image_label = fopen("../tc/train-labels.idx1-ubyte", "rb");
	if (image_train == NULL || image_label == NULL){
		cout << "can't open the file!" << endl;
		exit(0);
	}

	unsigned char image_buf[784];
	unsigned char label_buf[10];
	
	int useless[1000];
	fread(useless, 1, 16, image_train);
	fread(useless, 1, 8, image_label);

	int cnt = 0;
	cout << "Start training..." << endl;
	//60000 times
	while (!feof(image_train) && !feof(image_label)){
		memset(image_buf, 0, 784);
		memset(label_buf, 0, 10);
		fread(image_buf, 1, 784, image_train);
		fread(label_buf, 1, 1, image_label);

		//initialize the input by 28 x 28 (0,1)matrix of the images
		for (int i = 0; i < 784; i++){
			if ((unsigned int)image_buf[i] < 128){
				H[i] = 0;
			}
			else{
				H[i] = 1;
			}
		}

		//initialize the target output
		int target_value = (unsigned int)label_buf[0];
		for (int k = 0; k < third; k++){
			target[k] = 0;
		}
		target[target_value] = 1;

		//get the output and start training
		
	
		
		Forwardpropagation_1();
		Forwardpropagation_2();
		Perseus_3();
		Perseus_2();
		feedback_2();
	    feedback_3();
	
		cnt ++;
		if (cnt % 1000 == 0){
			cout << "training image: " << cnt << endl;
		}
	}
	cout << endl;
}
void testing(){
	FILE *image_test;
	FILE *image_test_label;
	image_test = fopen("../tc/t10k-images.idx3-ubyte", "rb");
	image_test_label = fopen("../tc/t10k-labels.idx1-ubyte", "rb");
	if (image_test == NULL || image_test_label == NULL){
		cout << "can't open the file!" << endl;
		exit(0);
	}

	unsigned char image_buf[784];
	unsigned char label_buf[10];
	
	int useless[1000];
	fread(useless, 1, 16, image_test);
	fread(useless, 1, 8, image_test_label);

	while (!feof(image_test) && !feof(image_test_label)){
		memset(image_buf, 0, 784);
		memset(label_buf, 0, 10);
		fread(image_buf, 1, 784, image_test);
		fread(label_buf, 1, 1, image_test_label);

		//initialize the input by 28 x 28 (0,1)matrix of the images
		for (int i = 0; i < 784; i++){
			if ((unsigned int)image_buf[i] < 128){
				H[i] = 0;
			}
			else{
				H[i] = 1;
			}
		}

		//initialize the target output
		for (int k = 0; k < third; k++){
			target[k] = 0;
		}
		int target_value = (unsigned int)label_buf[0];
		target[target_value] = 1;
		
		//get the ouput and compare with the target
		Forwardpropagation_1();
		Forwardpropagation_2();

		double max_value = -99999;
		int max_index = 0;
		for (int k = 0; k < third; k++){
			if (HH[k] > max_value){
				max_value = HH[k];
				max_index = k;
			}
		}

		//output == target
		if (target[max_index] == 1){
			test_success_count ++;
		}
		
		test_num ++;

		if ((int)test_num % 1000 == 0){
			cout << "test num: " << test_num << "  success: " << test_success_count << endl;
		}
	}
	cout << endl;
	cout << "The success rate: " << test_success_count / test_num << endl;
}
int main()
{
	initialize();
	training();
	testing();

	system("pause");
}
